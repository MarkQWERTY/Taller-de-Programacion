#Octavo ejercicio:

frase = str(input("Introduzca la frase que quieras para invertirla: "))    # Le pedimos al usuario que nos de una frase 
frasei = (frase [::-1])      
                                               # Con esta funcion invertimos la frase 
print ("La frase invertida quedaria tal que asi:",frasei)                   # Para finalizar, imprimos la frase invertida 
