#Septimo ejercicio:

nombre = str(input("Introduce tu nombre: "))    # Le pedimos al usuario que nos de un nombre

nombrem = (nombre.upper())      # Transformamos el nombre a mayusculas
numero = (len(nombre))          # Hacemos esta funcion para que nos de el numero de letras que tiene el nombre

print ("El nombre en mayusculas es:",nombrem,"y tiene",numero,"de letras")  # Finalmente imprimimos la frase querida